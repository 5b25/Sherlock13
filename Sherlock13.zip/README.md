# Sherlock13 Game

Client-Server deduction game with SDL2 visualization.

sudo apt-get install libbsd-dev
